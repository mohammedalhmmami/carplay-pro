import CarPlay
import Combine
import UIKit

/// The single source of truth for the real CarPlay connection state.
///
/// This class never fakes a connection: `isConnected` is true only while
/// a CPTemplateApplicationScene is actually connected to a car, as reported
/// by CPTemplateApplicationSceneDelegate. Everything the UI says about
/// CarPlay comes from here.
final class CarPlayManager: ObservableObject {
    static let shared = CarPlayManager()

    /// True only while a real CarPlay scene is connected.
    @Published private(set) var isConnected: Bool = false
    /// When the last connect/disconnect happened, if any.
    @Published private(set) var lastEvent: Date?
    /// True while the last-connected scene reported video support.
    @Published private(set) var lastSceneSupportsVideo: Bool = false
    /// Human-readable status line for the UI.
    @Published private(set) var statusLine: String = "غير متصل"

    private init() {}

    func sceneDidConnect(supportsVideo: Bool) {
        isConnected = true
        lastEvent = Date()
        lastSceneSupportsVideo = supportsVideo
        statusLine = supportsVideo ? "متصل — الفيديو مدعوم من السيارة" : "متصل — صوت فقط"
    }

    func sceneDidDisconnect() {
        isConnected = false
        lastEvent = Date()
        lastSceneSupportsVideo = false
        statusLine = "غير متصل"
    }
}
