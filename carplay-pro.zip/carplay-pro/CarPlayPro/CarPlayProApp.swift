import SwiftUI

@main
struct CarPlayProApp: App {
    @StateObject private var settings = SettingsStore()
    @StateObject private var audio = AudioService()
    @StateObject private var carPlay = CarPlayManager.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(settings)
                .environmentObject(audio)
                .environmentObject(carPlay)
                .onAppear {
                    audio.configureSession()
                    audio.loadLastAudio()
                }
                .onReceive(NotificationCenter.default.publisher(for: UIApplication.willEnterForegroundNotification)) { _ in
                    SmartTools.executePendingAction(settings: settings, audio: audio)
                }
        }
    }
}
