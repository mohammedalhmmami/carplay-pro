import CarPlay
import UIKit

/// CarPlay scene delegate. All CarPlay UI is built here and only here.
///
/// Honesty: this delegate is only ever called when the system actually
/// connects a CarPlay scene — which requires the CarPlay entitlements
/// (com.apple.developer.carplay-audio / carplay-video / carplay-maps)
/// provisioned by Apple for a paid developer account. A free-certificate
/// sideload strips them, so on the user's phone this code will not run
/// until Apple grants the entitlement. Nothing here fakes a connection:
/// connect/disconnect are reported verbatim to CarPlayManager, which is
/// the only thing the phone UI reads.
///
/// TEST-ONLY video path (iOS 26.4+): there is no CPVideoTemplate class.
/// Video is offered through CPPlaybackConfiguration on a CPListItem with
/// preferredPresentation = .video, shown only when the connected car
/// reports CPSessionConfiguration.supportsVideoPlayback. Parked-only,
/// AirPlay streaming, audio fallback when the car says no video.
final class CarPlaySceneDelegate: UIResponder, CPTemplateApplicationSceneDelegate {

    private var interfaceController: CPInterfaceController?

    // MARK: - CPTemplateApplicationSceneDelegate

    func templateApplicationScene(
        _ templateApplicationScene: CPTemplateApplicationScene,
        didConnect interfaceController: CPInterfaceController
    ) {
        self.interfaceController = interfaceController

        var supportsVideo = false
        if #available(iOS 26.4, *) {
            supportsVideo = templateApplicationScene.sessionConfiguration.supportsVideoPlayback
        }

        CarPlayManager.shared.sceneDidConnect(supportsVideo: supportsVideo)
        buildRootTemplate(interfaceController: interfaceController, supportsVideo: supportsVideo)
        offerResumeIfAvailable(interfaceController: interfaceController)
    }

    func templateApplicationScene(
        _ templateApplicationScene: CPTemplateApplicationScene,
        didDisconnect interfaceController: CPInterfaceController
    ) {
        self.interfaceController = nil
        CarPlayManager.shared.sceneDidDisconnect()
    }

    // MARK: - Templates

    private func buildRootTemplate(interfaceController: CPInterfaceController, supportsVideo: Bool) {
        let audioItem = CPListItem(
            text: "الصوت",
            detailText: "تشغيل واستئناف الصوت",
            image: nil,
            accessoryType: .disclosureIndicator
        ) { [weak self] _, completion in
            self?.showNowPlaying(interfaceController: interfaceController)
            completion()
        }

        let mapsItem = CPListItem(
            text: "الملاحة",
            detailText: "خريطة واتجاهات",
            image: nil,
            accessoryType: .disclosureIndicator
        ) { [weak self] _, completion in
            self?.showMap(interfaceController: interfaceController)
            completion()
        }

        var items: [CPListItem] = [audioItem, mapsItem]

        // Test-only video section: only when the car reports video support.
        if #available(iOS 26.4, *), supportsVideo {
            let videoItem = CPListItem(
                text: "فيديو (تجريبي)",
                detailText: "فيديو أثناء الوقوف فقط — تجريبي",
                image: nil,
                accessoryType: .disclosureIndicator
            )
            videoItem.playbackConfiguration = CPPlaybackConfiguration(
                elapsedTime: 0,
                duration: 0,
                playbackAction: .play
            )
            videoItem.playbackConfiguration?.preferredPresentation = .video
            items.append(videoItem)
        }

        let section = CPListSection(items: items, header: "كاربلاي برو", sectionIndexTitle: nil)
        let list = CPListTemplate(title: "كاربلاي برو", sections: [section])

        if #available(iOS 26.4, *), supportsVideo {
            // Video gets its own tab only when the car supports video.
            let tabBar = CPTabBarTemplate(templates: [list, CPNowPlayingTemplate.shared])
            tabBar.tabBarItem.title = "كاربلاي برو"
            interfaceController.setRootTemplate(tabBar, animated: false, completion: nil)
        } else {
            interfaceController.setRootTemplate(list, animated: false, completion: nil)
        }
    }

    private func showNowPlaying(interfaceController: CPInterfaceController) {
        interfaceController.pushTemplate(CPNowPlayingTemplate.shared, animated: true, completion: nil)
    }

    private func showMap(interfaceController: CPInterfaceController) {
        let map = CPMapTemplate()
        interfaceController.pushTemplate(map, animated: true, completion: nil)
    }

    // MARK: - Auto-resume offer (offer only, never auto-play)

    /// When CarPlay connects, OFFER to resume the last audio — never
    /// auto-play. The user taps "استئناف" or "لاحقاً".
    private func offerResumeIfAvailable(interfaceController: CPInterfaceController) {
        let defaults = UserDefaults.standard
        guard let urlString = defaults.string(forKey: "cp.lastAudioURL"),
              !urlString.isEmpty else { return }
        let title = defaults.string(forKey: "cp.lastAudioTitle") ?? "آخر صوت"

        let resume = CPAlertAction(title: "استئناف", style: .default) { _, completion in
            // Hand playback to the phone app via the shared AudioService:
            // the CarPlay side only signals; the phone app owns the player.
            NotificationCenter.default.post(
                name: .cpResumeAudioRequested,
                object: nil
            )
            completion()
        }
        let later = CPAlertAction(title: "لاحقاً", style: .cancel) { _, completion in
            completion()
        }
        let alert = CPAlertTemplate(
            titleVariants: ["استئناف \(title)؟"],
            actions: [resume, later]
        )
        // Show the offer as a message, not as an auto-play.
        interfaceController.presentTemplate(alert, animated: true, completion: nil)
    }
}

extension Notification.Name {
    /// Posted from the CarPlay scene when the user accepts the resume offer.
    static let cpResumeAudioRequested = Notification.Name("cpResumeAudioRequested")
}
