import AppIntents
import Foundation

/// Siri Shortcuts for the main actions, using AppIntents (iOS 16+).
///
/// These intents do NOT run in the background: they open the app
/// (`openAppWhenRun = true`) and store a pending action in UserDefaults;
/// the app executes it when it appears. That is the honest limit of what
/// an AppIntent can do here without a CarPlay entitlement or background
/// audio session tricks.
struct NavigateHomeIntent: AppIntent {
    static var title: LocalizedStringResource = "التوجّه إلى المنزل"
    static var openAppWhenRun: Bool = true

    func perform() async throws -> some IntentResult & ProvidesDialog {
        SettingsStore.setPendingAction(SmartTools.PendingAction.navigateHome.rawValue)
        return .result(dialog: "سأفتح الملاحة إلى المنزل")
    }
}

struct NavigateWorkIntent: AppIntent {
    static var title: LocalizedStringResource = "التوجّه إلى العمل"
    static var openAppWhenRun: Bool = true

    func perform() async throws -> some IntentResult & ProvidesDialog {
        SettingsStore.setPendingAction(SmartTools.PendingAction.navigateWork.rawValue)
        return .result(dialog: "سأفتح الملاحة إلى العمل")
    }
}

struct ResumeAudioIntent: AppIntent {
    static var title: LocalizedStringResource = "استئناف آخر صوت"
    static var openAppWhenRun: Bool = true

    func perform() async throws -> some IntentResult & ProvidesDialog {
        SettingsStore.setPendingAction(SmartTools.PendingAction.resumeAudio.rawValue)
        return .result(dialog: "سأستأنف آخر صوت")
    }
}

struct OpenYouTubeIntent: AppIntent {
    static var title: LocalizedStringResource = "فتح يوتيوب"
    static var openAppWhenRun: Bool = true

    func perform() async throws -> some IntentResult & ProvidesDialog {
        SettingsStore.setPendingAction(SmartTools.PendingAction.openYouTube.rawValue)
        return .result(dialog: "سأفتح يوتيوب على الهاتف")
    }
}

/// Exposes the intents to Siri and the Shortcuts app.
/// Every phrase includes \(.applicationName) as required by AppShortcuts.
struct CarPlayProShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: NavigateHomeIntent(),
            phrases: ["التوجّه إلى المنزل في \(.applicationName)", "خذني إلى البيت في \(.applicationName)"],
            shortTitle: "المنزل",
            systemImageName: "house.fill"
        )
        AppShortcut(
            intent: NavigateWorkIntent(),
            phrases: ["التوجّه إلى العمل في \(.applicationName)", "خذني إلى العمل في \(.applicationName)"],
            shortTitle: "العمل",
            systemImageName: "briefcase.fill"
        )
        AppShortcut(
            intent: ResumeAudioIntent(),
            phrases: ["استئناف الصوت في \(.applicationName)", "شغّل آخر صوت في \(.applicationName)"],
            shortTitle: "استئناف الصوت",
            systemImageName: "play.fill"
        )
        AppShortcut(
            intent: OpenYouTubeIntent(),
            phrases: ["افتح يوتيوب في \(.applicationName)", "شغّل يوتيوب في \(.applicationName)"],
            shortTitle: "يوتيوب",
            systemImageName: "play.rectangle.fill"
        )
    }
}
