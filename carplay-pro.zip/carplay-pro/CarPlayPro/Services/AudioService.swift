import AVFoundation
import Combine
import MediaPlayer
import UIKit

/// Audio playback for the phone: an AVPlayer stream player plus
/// Now Playing integration (lock screen + Control Center + CarPlay
/// Now Playing template when a real CarPlay session exists).
///
/// No stream URL is hardcoded: the user pastes a stream URL, or the
/// player resumes the last URL the user entered. Nothing here plays
/// audio to the car screen — CarPlay audio is handled by the system
/// through MPNowPlayingInfoCenter / CPNowPlayingTemplate.
final class AudioService: ObservableObject {
    @Published private(set) var isPlaying: Bool = false
    @Published private(set) var currentTitle: String = ""
    @Published private(set) var currentURLString: String = ""
    @Published private(set) var duration: Double = 0
    @Published private(set) var position: Double = 0

    private var player: AVPlayer?
    private var timeObserver: Any?
    private var cancellables = Set<AnyCancellable>()
    private weak var settings: SettingsStore?

    deinit {
        if let observer = timeObserver {
            player?.removeTimeObserver(observer)
        }
    }

    // MARK: - Session

    func configureSession() {
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [])
            try session.setActive(true)
        } catch {
            // Audio still works without an active session; keep going.
            print("CarPlayPro: AVAudioSession setup failed: \(error.localizedDescription)")
        }
        setupRemoteCommands()
    }

    // MARK: - Playback

    /// Play a stream URL entered by the user. Empty or malformed URLs are ignored.
    func play(urlString: String, title: String = "", settings: SettingsStore? = nil) {
        guard let url = URL(string: urlString.trimmingCharacters(in: .whitespaces)),
              url.scheme == "http" || url.scheme == "https" else { return }
        if let settings = settings { self.settings = settings }
        stopTimeObserver()

        let item = AVPlayerItem(url: url)
        if player == nil {
            player = AVPlayer(playerItem: item)
        } else {
            player?.replaceCurrentItem(with: item)
        }
        currentURLString = urlString
        currentTitle = title.isEmpty ? url.host ?? urlString : title
        player?.play()
        isPlaying = true
        startTimeObserver()
        updateNowPlaying()
        persistLastAudio()
    }

    /// Resume the last audio the user played (URL + position from Settings).
    func resumeLast(settings: SettingsStore) {
        self.settings = settings
        guard !settings.lastAudioURL.isEmpty else { return }
        play(urlString: settings.lastAudioURL, title: settings.lastAudioTitle, settings: settings)
        if settings.lastAudioPosition > 1 {
            let target = CMTime(seconds: settings.lastAudioPosition, preferredTimescale: 1)
            player?.seek(to: target)
        }
    }

    /// Load the last audio info for display without starting playback.
    func loadLastAudio() {
        let defaults = UserDefaults.standard
        currentURLString = defaults.string(forKey: "cp.lastAudioURL") ?? ""
        currentTitle = defaults.string(forKey: "cp.lastAudioTitle") ?? ""
    }

    func pause() {
        player?.pause()
        isPlaying = false
        updateNowPlaying()
        persistLastAudio()
    }

    func togglePlayPause() {
        if isPlaying { pause() } else { player?.play(); isPlaying = true; updateNowPlaying() }
    }

    func seek(to seconds: Double) {
        let target = CMTime(seconds: seconds, preferredTimescale: 1)
        player?.seek(to: target)
        updateNowPlaying()
    }

    // MARK: - Now Playing

    private func updateNowPlaying() {
        var info: [String: Any] = [:]
        info[MPMediaItemPropertyTitle] = currentTitle.isEmpty ? "كاربلاي برو" : currentTitle
        info[MPMediaItemPropertyArtist] = "CarPlay Pro"
        info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = position
        info[MPNowPlayingInfoPropertyPlaybackDuration] = duration
        info[MPNowPlayingInfoPropertyPlaybackRate] = isPlaying ? 1.0 : 0.0
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }

    private func setupRemoteCommands() {
        let center = MPRemoteCommandCenter.shared()
        center.playCommand.addTarget { [weak self] _ in
            self?.player?.play()
            self?.isPlaying = true
            self?.updateNowPlaying()
            return .success
        }
        center.pauseCommand.addTarget { [weak self] _ in
            self?.pause()
            return .success
        }
        center.togglePlayPauseCommand.addTarget { [weak self] _ in
            self?.togglePlayPause()
            return .success
        }
    }

    // MARK: - Helpers

    private func startTimeObserver() {
        let interval = CMTime(seconds: 1, preferredTimescale: 1)
        timeObserver = player?.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            guard let self = self else { return }
            self.position = time.seconds
            if let item = self.player?.currentItem {
                let d = item.duration.seconds
                if d.isFinite { self.duration = d }
            }
            self.updateNowPlaying()
            self.persistLastAudio()
        }
    }

    private func stopTimeObserver() {
        if let observer = timeObserver {
            player?.removeTimeObserver(observer)
            timeObserver = nil
        }
    }

    private func persistLastAudio() {
        guard let settings = settings else { return }
        settings.lastAudioURL = currentURLString
        settings.lastAudioTitle = currentTitle
        settings.lastAudioPosition = position
    }
}
