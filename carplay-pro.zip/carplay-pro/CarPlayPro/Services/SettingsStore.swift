import Combine
import Foundation

/// Local user settings, stored only in UserDefaults on this phone.
/// No account, no server, no invented addresses — everything here is
/// either empty by default or typed in by the user in Settings.
final class SettingsStore: ObservableObject {
    private enum Key {
        static let homeAddress = "cp.homeAddress"
        static let workAddress = "cp.workAddress"
        static let pendingAction = "cp.pendingAction"
        static let lastAudioURL = "cp.lastAudioURL"
        static let lastAudioTitle = "cp.lastAudioTitle"
        static let lastAudioPosition = "cp.lastAudioPosition"
    }

    @Published var homeAddress: String {
        didSet { UserDefaults.standard.set(homeAddress, forKey: Key.homeAddress) }
    }
    @Published var workAddress: String {
        didSet { UserDefaults.standard.set(workAddress, forKey: Key.workAddress) }
    }
    /// URL of the last audio stream the user played.
    @Published var lastAudioURL: String {
        didSet { UserDefaults.standard.set(lastAudioURL, forKey: Key.lastAudioURL) }
    }
    @Published var lastAudioTitle: String {
        didSet { UserDefaults.standard.set(lastAudioTitle, forKey: Key.lastAudioTitle) }
    }
    /// Last playback position in seconds, for resume.
    @Published var lastAudioPosition: Double {
        didSet { UserDefaults.standard.set(lastAudioPosition, forKey: Key.lastAudioPosition) }
    }

    init() {
        let defaults = UserDefaults.standard
        self.homeAddress = defaults.string(forKey: Key.homeAddress) ?? ""
        self.workAddress = defaults.string(forKey: Key.workAddress) ?? ""
        self.lastAudioURL = defaults.string(forKey: Key.lastAudioURL) ?? ""
        self.lastAudioTitle = defaults.string(forKey: Key.lastAudioTitle) ?? ""
        self.lastAudioPosition = defaults.double(forKey: Key.lastAudioPosition)
    }

    var hasHome: Bool { !homeAddress.trimmingCharacters(in: .whitespaces).isEmpty }
    var hasWork: Bool { !workAddress.trimmingCharacters(in: .whitespaces).isEmpty }

    // MARK: - Pending action (set by Siri Shortcuts, executed by the app)

    static func setPendingAction(_ rawValue: String) {
        UserDefaults.standard.set(rawValue, forKey: Key.pendingAction)
    }

    static func takePendingAction() -> String? {
        let value = UserDefaults.standard.string(forKey: Key.pendingAction)
        if value != nil {
            UserDefaults.standard.removeObject(forKey: Key.pendingAction)
        }
        return value
    }
}
