import Foundation
import UIKit

/// One-tap smart actions. Honest by design:
/// - They are simple rules, not AI: a time-of-day suggestion is just the
///   clock plus the addresses the user typed in Settings.
/// - Anything that needs a CarPlay entitlement is labelled gated and never
///   claimed to work before Apple grants it.
/// - Addresses come only from the user (UserDefaults). Nothing is invented.
enum SmartTools {

    enum PendingAction: String {
        case navigateHome = "navigateHome"
        case navigateWork = "navigateWork"
        case resumeAudio = "resumeAudio"
        case openYouTube = "openYouTube"
    }

    // MARK: - Time-of-day suggestion (a clock rule, not AI)

    /// Morning (05:00–12:00) → work if set; evening (17:00–23:00) → home if set;
    /// otherwise resume audio / open YouTube.
    static func suggestedAction(settings: SettingsStore) -> (title: String, action: PendingAction?) {
        let hour = Calendar.current.component(.hour, from: Date())
        if (5..<12).contains(hour), settings.hasWork {
            return ("اقتراح الصباح: التوجّه إلى العمل", .navigateWork)
        }
        if (17..<23).contains(hour), settings.hasHome {
            return ("اقتراح المساء: التوجّه إلى المنزل", .navigateHome)
        }
        if !settings.lastAudioURL.isEmpty {
            return ("اقتراح الآن: استئناف آخر صوت", .resumeAudio)
        }
        return ("اقتراح الآن: فتح يوتيوب على الهاتف", .openYouTube)
    }

    // MARK: - Execution

    /// Execute a pending action set by a Siri Shortcut (via UserDefaults).
    /// Called when the app appears / returns to foreground.
    static func executePendingAction(settings: SettingsStore, audio: AudioService) {
        guard let raw = SettingsStore.takePendingAction(),
              let action = PendingAction(rawValue: raw) else { return }
        execute(action, settings: settings, audio: audio)
    }

    static func execute(_ action: PendingAction, settings: SettingsStore, audio: AudioService) {
        switch action {
        case .navigateHome:
            navigate(to: settings.homeAddress)
        case .navigateWork:
            navigate(to: settings.workAddress)
        case .resumeAudio:
            audio.resumeLast(settings: settings)
        case .openYouTube:
            NotificationCenter.default.post(name: .cpOpenYouTubeTab, object: nil)
        }
    }

    /// Open Apple Maps with driving directions to an address the user typed.
    /// Does nothing when the address is empty — no invented destination.
    static func navigate(to address: String) {
        let trimmed = address.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty,
              let encoded = trimmed.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "http://maps.apple.com/?daddr=\(encoded)&dirflg=d") else { return }
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }

    static func openYouTube() {
        NotificationCenter.default.post(name: .cpOpenYouTubeTab, object: nil)
    }
}

extension Notification.Name {
    /// Posted when a smart action asks the phone UI to switch to the YouTube tab.
    static let cpOpenYouTubeTab = Notification.Name("cpOpenYouTubeTab")
}
