import SwiftUI

/// Audio player on the phone: user-entered stream URL + resume.
/// Now Playing info is published by AudioService, so the lock screen,
/// Control Center and (when really connected) CarPlay Now Playing
/// all show the same track.
struct AudioView: View {
    @EnvironmentObject private var settings: SettingsStore
    @EnvironmentObject private var audio: AudioService
    @State private var urlText: String = ""
    @State private var titleText: String = ""
    @State private var showSavedMessage: Bool = false

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .trailing, spacing: 16) {
                    SectionCard(title: "المشغّل", icon: "music.note") {
                        VStack(alignment: .trailing, spacing: 12) {
                            if !audio.currentTitle.isEmpty {
                                Text(audio.currentTitle)
                                    .font(.headline)
                                Text(audio.currentURLString)
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                    .lineLimit(2)
                            } else {
                                Text("لا يوجد صوت قيد التشغيل")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }

                            HStack {
                                Text(formattedTime(audio.position))
                                Slider(value: Binding(
                                    get: { audio.position },
                                    set: { audio.seek(to: $0) }
                                ), in: 0...max(audio.duration, 1))
                                Text(formattedTime(audio.duration))
                            }
                            .font(.caption)
                            .foregroundColor(.secondary)

                            HStack(spacing: 24) {
                                Button(action: { audio.togglePlayPause() }) {
                                    Image(systemName: audio.isPlaying ? "pause.circle.fill" : "play.circle.fill")
                                        .font(.system(size: 56))
                                }
                                .disabled(audio.currentURLString.isEmpty && settings.lastAudioURL.isEmpty)
                            }
                            .frame(maxWidth: .infinity)
                        }
                    }

                    SectionCard(title: "تشغيل رابط صوتي", icon: "link") {
                        VStack(alignment: .trailing, spacing: 10) {
                            TextField("رابط البث (http/https)", text: $urlText)
                                .textFieldStyle(.roundedBorder)
                                .autocapitalization(.none)
                                .keyboardType(.URL)
                            TextField("اسم الصوت (اختياري)", text: $titleText)
                                .textFieldStyle(.roundedBorder)
                            Button("تشغيل") {
                                audio.play(urlString: urlText, title: titleText, settings: settings)
                                showSavedMessage = true
                            }
                            .buttonStyle(.borderedProminent)
                            .disabled(urlText.trimmingCharacters(in: .whitespaces).isEmpty)
                            if showSavedMessage {
                                Text("تم حفظ الرابط كآخر صوت للاستئناف لاحقاً")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }

                    if !settings.lastAudioURL.isEmpty {
                        SectionCard(title: "آخر صوت", icon: "clock.arrow.circlepath") {
                            VStack(alignment: .trailing, spacing: 8) {
                                Text(settings.lastAudioTitle.isEmpty ? settings.lastAudioURL : settings.lastAudioTitle)
                                    .font(.subheadline)
                                Text("الموضع المحفوظ: \(formattedTime(settings.lastAudioPosition))")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                Button("استئناف من الموضع المحفوظ") {
                                    audio.resumeLast(settings: settings)
                                }
                                .buttonStyle(.bordered)
                            }
                        }
                    }

                    Text("الصوت يعمل على الهاتف ويظهر في Now Playing. عند اتصال CarPlay حقيقي يظهر نفسه في قالب Now Playing على الشاشة.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                .padding()
            }
            .navigationTitle("صوت")
        }
        .navigationViewStyle(.stack)
        .onAppear {
            if urlText.isEmpty, !settings.lastAudioURL.isEmpty {
                urlText = settings.lastAudioURL
                titleText = settings.lastAudioTitle
            }
        }
    }
}
