import SwiftUI
import UIKit

/// "Car apps": the apps on THIS phone that declare CarPlay support,
/// detected by asking the system which URL schemes the phone can open.
/// This is a real check (canOpenURL), not a hardcoded list — but it can
/// only see schemes declared in LSApplicationQueriesSchemes, and it
/// cannot know whether an app is actually CarPlay-enabled on the car.
/// Anything here is labelled as "on the phone", and the CarPlay side
/// itself stays gated behind the entitlement.
struct CarAppsView: View {
    struct CarAppEntry: Identifiable {
        let id: String
        let name: String
        let scheme: String
        let note: String
    }

    // Well-known schemes of apps that commonly offer CarPlay, each
    // declared in Info.plist LSApplicationQueriesSchemes. canOpenURL is
    // the real test; an absent app simply shows as not installed.
    private let candidates: [CarAppEntry] = [
        CarAppEntry(id: "maps", name: "خرائط Apple", scheme: "maps://", note: "ملاحة — CarPlay أصلي من Apple"),
        CarAppEntry(id: "googlemaps", name: "Google Maps", scheme: "comgooglemaps://", note: "ملاحة — يدعم CarPlay"),
        CarAppEntry(id: "waze", name: "Waze", scheme: "waze://", note: "ملاحة — يدعم CarPlay"),
        CarAppEntry(id: "spotify", name: "Spotify", scheme: "spotify://", note: "صوت — يدعم CarPlay"),
        CarAppEntry(id: "youtubemusic", name: "YouTube Music", scheme: "youtubemusic://", note: "صوت — يدعم CarPlay"),
        CarAppEntry(id: "whatsapp", name: "WhatsApp", scheme: "whatsapp://", note: "رسائل — يدعم CarPlay"),
        CarAppEntry(id: "telegram", name: "Telegram", scheme: "tg://", note: "رسائل — يدعم CarPlay")
    ]

    @State private var installed: Set<String> = []

    var body: some View {
        NavigationView {
            List {
                Section(header: Text("مثبّت على هذا الهاتف")) {
                    if installed.isEmpty {
                        Text("لم يُعثر على أي تطبيق من القائمة على هذا الهاتف")
                            .foregroundColor(.secondary)
                    } else {
                        ForEach(candidates.filter { installed.contains($0.id) }) { app in
                            VStack(alignment: .trailing, spacing: 4) {
                                Text(app.name)
                                    .font(.headline)
                                Text(app.note)
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                }
                Section(header: Text("غير مثبّت")) {
                    ForEach(candidates.filter { !installed.contains($0.id) }) { app in
                        VStack(alignment: .trailing, spacing: 4) {
                            Text(app.name)
                                .foregroundColor(.secondary)
                            Text("غير مثبّت على الهاتف")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                Section(footer: Text("هذا الفحص يتحقق من وجود التطبيق على الهاتف فقط. ظهوره على شاشة السيارة يتطلب أن يدعم التطبيق CarPlay وأن تكون صلاحية CarPlay ممنوحة — وهذا خارج سيطرة هذا التطبيق.")) {
                    EmptyView()
                }
            }
            .navigationTitle("تطبيقات السيارة")
        }
        .navigationViewStyle(.stack)
        .onAppear(perform: detectInstalled)
    }

    private func detectInstalled() {
        var found = Set<String>()
        for app in candidates {
            if let url = URL(string: app.scheme),
               UIApplication.shared.canOpenURL(url) {
                found.insert(app.id)
            }
        }
        installed = found
    }
}
