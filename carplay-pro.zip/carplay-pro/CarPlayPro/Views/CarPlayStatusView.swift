import SwiftUI

/// The CarPlay status screen: the real connection state, and the
/// entitlement gate stated plainly. Nothing here is faked — the state
/// comes only from CarPlayManager, which is fed by the real
/// CPTemplateApplicationSceneDelegate callbacks.
struct CarPlayStatusView: View {
    @EnvironmentObject private var carPlay: CarPlayManager

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .trailing, spacing: 16) {
                    SectionCard(title: "حالة الاتصال الحالية", icon: "carplay") {
                        VStack(alignment: .trailing, spacing: 8) {
                            HStack {
                                Image(systemName: carPlay.isConnected ? "checkmark.circle.fill" : "xmark.circle.fill")
                                    .foregroundColor(carPlay.isConnected ? .green : .red)
                                Text(carPlay.statusLine)
                                    .font(.headline)
                                Spacer()
                            }
                            if let event = carPlay.lastEvent {
                                Text("آخر تغيير: \(event.formatted(date: .abbreviated, time: .shortened))")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            } else {
                                Text("لم يتصل التطبيق بـ CarPlay منذ تثبيته")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            if carPlay.isConnected {
                                Text("الفيديو من السيارة: \(carPlay.lastSceneSupportsVideo ? "مدعوم" : "غير مدعوم — صوت فقط")")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }

                    SectionCard(title: "لماذا لا يظهر التطبيق على شاشة السيارة؟", icon: "exclamationmark.triangle.fill") {
                        VStack(alignment: .trailing, spacing: 8) {
                            Text("تمنح Apple صلاحيات CarPlay (carplay-audio و carplay-video و carplay-maps) لحسابات المطوّرين المدفوعة فقط، بعد طلب وموافقة. الشهادة المجانية لا تحمل هذه الصلاحيات، وإعادة التوقيع عبر SideStore تُزيلها.")
                                .font(.subheadline)
                            Text("هذا يعني: الكود كامل وجاهز في التطبيق، لكن النظام لن يفتح مشهد CarPlay له أبداً حتى تمنح Apple الصلاحية لحساب مطوّر مدفوع. لا يوجد كود أو إعداد داخل التطبيق يكسر هذا القيد — القيد في توقيع Apple وليس في التطبيق.")
                                .font(.subheadline)
                            Text("هذا التطبيق تجريبي يُثبَّت بشهادة، وليس تطبيق متجر رسمي.")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }

                    SectionCard(title: "ماذا يعمل الآن؟", icon: "checkmark.seal.fill") {
                        VStack(alignment: .trailing, spacing: 6) {
                            StatusLine(text: "يوتيوب على الهاتف (فيديو وصوت)", works: true)
                            StatusLine(text: "مشغّل الصوت و Now Playing على الهاتف", works: true)
                            StatusLine(text: "الملاحة على الهاتف", works: true)
                            StatusLine(text: "الأدوات الذكية واختصارات Siri", works: true)
                            StatusLine(text: "قوالب CarPlay على شاشة السيارة", works: false, note: "تنتظر صلاحية Apple")
                            StatusLine(text: "فيديو CarPlay أثناء الوقوف (تجريبي)", works: false, note: "ينتظر الصلاحية + سيارة تدعم الفيديو + iOS 26.4")
                        }
                    }

                    SectionCard(title: "يوتيوب على شاشة السيارة؟", icon: "play.rectangle.fill") {
                        Text("لا يمكن لتطبيق طرف ثالث عرض فيديو يوتيوب على شاشة السيارة عبر CarPlay. فئة الفيديو في CarPlay جديدة (iOS 27)، مقيدة بالوقوف فقط، وتتطلب صلاحية carplay-video من Apple ولم تفعّلها أي شركة سيارات حتى الآن. أي تطبيق يدّعي غير ذلك فهو وهمي.")
                            .font(.subheadline)
                    }
                }
                .padding()
            }
            .navigationTitle("حالة CarPlay")
        }
        .navigationViewStyle(.stack)
    }
}

private struct StatusLine: View {
    let text: String
    let works: Bool
    var note: String?

    var body: some View {
        HStack {
            Image(systemName: works ? "checkmark.circle.fill" : "xmark.circle.fill")
                .foregroundColor(works ? .green : .orange)
            VStack(alignment: .trailing, spacing: 2) {
                Text(text)
                    .font(.subheadline)
                if let note = note {
                    Text(note)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            Spacer()
        }
    }
}
