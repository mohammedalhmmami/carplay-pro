import SwiftUI

enum AppTab: Hashable {
    case home
    case youtube
    case audio
    case map
    case carApps
    case status
    case settings
}

struct ContentView: View {
    @EnvironmentObject private var settings: SettingsStore
    @EnvironmentObject private var audio: AudioService
    @EnvironmentObject private var carPlay: CarPlayManager
    @State private var selectedTab: AppTab = .home

    var body: some View {
        TabView(selection: $selectedTab) {
            HomeView(selectedTab: $selectedTab)
                .tabItem { Label("الرئيسية", systemImage: "house.fill") }
                .tag(AppTab.home)
            YouTubeView()
                .tabItem { Label("يوتيوب", systemImage: "play.rectangle.fill") }
                .tag(AppTab.youtube)
            AudioView()
                .tabItem { Label("صوت", systemImage: "music.note") }
                .tag(AppTab.audio)
            MapView()
                .tabItem { Label("ملاحة", systemImage: "map.fill") }
                .tag(AppTab.map)
            CarAppsView()
                .tabItem { Label("تطبيقات السيارة", systemImage: "car.fill") }
                .tag(AppTab.carApps)
            CarPlayStatusView()
                .tabItem { Label("حالة CarPlay", systemImage: "carplay") }
                .tag(AppTab.status)
            SettingsView()
                .tabItem { Label("الإعدادات", systemImage: "gearshape.fill") }
                .tag(AppTab.settings)
        }
        .environment(\.layoutDirection, .rightToLeft)
        .onReceive(NotificationCenter.default.publisher(for: .cpOpenYouTubeTab)) { _ in
            selectedTab = .youtube
        }
        .onReceive(NotificationCenter.default.publisher(for: .cpResumeAudioRequested)) { _ in
            audio.resumeLast(settings: settings)
        }
        .onAppear {
            SmartTools.executePendingAction(settings: settings, audio: audio)
        }
    }
}
