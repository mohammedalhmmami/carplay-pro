import SwiftUI

/// Home: big sections + the smart tools (one-tap actions).
/// Smart tools are simple, honest rules — no AI claim anywhere.
struct HomeView: View {
    @EnvironmentObject private var settings: SettingsStore
    @EnvironmentObject private var audio: AudioService
    @EnvironmentObject private var carPlay: CarPlayManager
    @Binding var selectedTab: AppTab

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .trailing, spacing: 16) {
                    // Connection banner — always honest.
                    HStack {
                        Image(systemName: carPlay.isConnected ? "checkmark.circle.fill" : "xmark.circle.fill")
                            .foregroundColor(carPlay.isConnected ? .green : .red)
                        Text(carPlay.isConnected ? "متصل بـ CarPlay" : "غير متصل بـ CarPlay")
                            .font(.headline)
                        Spacer()
                        Button("التفاصيل") { selectedTab = .status }
                            .font(.subheadline)
                    }
                    .padding()
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(16)

                    // MARK: - Smart tools
                    SectionCard(title: "أدوات ذكية", icon: "bolt.fill") {
                        VStack(spacing: 10) {
                            SmartActionRow(
                                title: "التوجّه إلى المنزل",
                                icon: "house.fill",
                                enabled: settings.hasHome,
                                disabledNote: "أضف عنوان المنزل من الإعدادات"
                            ) {
                                SmartTools.execute(.navigateHome, settings: settings, audio: audio)
                            }
                            SmartActionRow(
                                title: "التوجّه إلى العمل",
                                icon: "briefcase.fill",
                                enabled: settings.hasWork,
                                disabledNote: "أضف عنوان العمل من الإعدادات"
                            ) {
                                SmartTools.execute(.navigateWork, settings: settings, audio: audio)
                            }
                            SmartActionRow(
                                title: "استئناف آخر صوت",
                                icon: "play.fill",
                                enabled: !settings.lastAudioURL.isEmpty,
                                disabledNote: "لا يوجد صوت سابق بعد"
                            ) {
                                SmartTools.execute(.resumeAudio, settings: settings, audio: audio)
                            }
                            SmartActionRow(
                                title: "فتح يوتيوب على الهاتف",
                                icon: "play.rectangle.fill",
                                enabled: true,
                                disabledNote: nil
                            ) {
                                SmartTools.execute(.openYouTube, settings: settings, audio: audio)
                            }

                            Divider()

                            // Time-of-day suggestion: a clock rule, labelled as such.
                            let suggestion = SmartTools.suggestedAction(settings: settings)
                            VStack(alignment: .trailing, spacing: 6) {
                                Text(suggestion.title)
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                                Text("اقتراح حسب الوقت فقط — ليس ذكاءً اصطناعياً")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                if let action = suggestion.action {
                                    Button("تنفيذ الاقتراح") {
                                        SmartTools.execute(action, settings: settings, audio: audio)
                                    }
                                    .buttonStyle(.borderedProminent)
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .trailing)
                        }
                    }

                    // MARK: - Main sections
                    HomeRow(title: "يوتيوب", subtitle: "فيديو وصوت على الهاتف — ليس على شاشة السيارة", icon: "play.rectangle.fill") {
                        selectedTab = .youtube
                    }
                    HomeRow(title: "صوت", subtitle: "مشغّل صوت مع Now Playing", icon: "music.note") {
                        selectedTab = .audio
                    }
                    HomeRow(title: "ملاحة", subtitle: "خريطة واتجاهات على الهاتف", icon: "map.fill") {
                        selectedTab = .map
                    }
                    HomeRow(title: "تطبيقات السيارة", subtitle: "التطبيقات التي تدعم CarPlay", icon: "car.fill") {
                        selectedTab = .carApps
                    }
                    HomeRow(title: "حالة CarPlay", subtitle: "الاتصال الحقيقي وصلاحية Apple", icon: "carplay") {
                        selectedTab = .status
                    }

                    Text("نسخة تجريبية 1.0 — تُثبَّت بشهادة، وليست تطبيق متجر رسمي")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity)
                }
                .padding()
            }
            .navigationTitle("كاربلاي برو")
        }
        .navigationViewStyle(.stack)
    }
}

private struct SmartActionRow: View {
    let title: String
    let icon: String
    let enabled: Bool
    let disabledNote: String?
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack {
                VStack(alignment: .trailing, spacing: 2) {
                    Text(title)
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(enabled ? .primary : .secondary)
                    if !enabled, let note = disabledNote {
                        Text(note)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                Spacer()
                Image(systemName: icon)
                    .foregroundColor(enabled ? .accentColor : .secondary)
            }
            .padding(.vertical, 4)
        }
        .disabled(!enabled)
    }
}
