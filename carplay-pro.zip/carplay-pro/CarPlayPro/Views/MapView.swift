import MapKit
import SwiftUI

/// Map on the PHONE (MKMapView). The CarPlay side uses CPMapTemplate,
/// which only exists while a real CarPlay scene is connected.
struct MapView: View {
    @EnvironmentObject private var settings: SettingsStore
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 24.7136, longitude: 46.6753),
        span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
    )
    @State private var didCenterOnUser: Bool = false

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                PhoneMapView(region: $region, didCenterOnUser: $didCenterOnUser)
                    .edgesIgnoringSafeArea(.bottom)

                HStack(spacing: 16) {
                    Button("المنزل") {
                        if settings.hasHome { SmartTools.navigate(to: settings.homeAddress) }
                    }
                    .disabled(!settings.hasHome)
                    Button("العمل") {
                        if settings.hasWork { SmartTools.navigate(to: settings.workAddress) }
                    }
                    .disabled(!settings.hasWork)
                    Button("موقعي") {
                        didCenterOnUser = false
                    }
                }
                .font(.subheadline)
                .padding(.vertical, 8)

                if !settings.hasHome && !settings.hasWork {
                    Text("أضف عنوان المنزل والعمل من الإعدادات لتظهر أزرار الملاحة هنا")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .padding(.bottom, 8)
                }
            }
            .navigationTitle("ملاحة")
            .navigationBarTitleDisplayMode(.inline)
        }
        .navigationViewStyle(.stack)
    }
}

struct PhoneMapView: UIViewRepresentable {
    @Binding var region: MKCoordinateRegion
    @Binding var didCenterOnUser: Bool

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        mapView.showsUserLocation = true
        mapView.userTrackingMode = .follow
        return mapView
    }

    func updateUIView(_ mapView: MKMapView, context: Context) {
        // Center once on the user; afterwards never fight the user's panning.
        if !didCenterOnUser, let location = mapView.userLocation.location {
            let newRegion = MKCoordinateRegion(
                center: location.coordinate,
                span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
            )
            mapView.setRegion(newRegion, animated: true)
            DispatchQueue.main.async {
                self.didCenterOnUser = true
            }
        }
    }

    final class Coordinator: NSObject, MKMapViewDelegate {
        var parent: PhoneMapView

        init(parent: PhoneMapView) {
            self.parent = parent
        }
    }
}
