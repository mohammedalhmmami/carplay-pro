import SwiftUI

/// Settings: the user's own home/work addresses (UserDefaults only),
/// plus plain explanations of the smart tools and Siri Shortcuts.
/// No account, no server, no invented data.
struct SettingsView: View {
    @EnvironmentObject private var settings: SettingsStore

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("عناويني (تُحفظ على الهاتف فقط)")) {
                    TextField("عنوان المنزل", text: $settings.homeAddress)
                    TextField("عنوان العمل", text: $settings.workAddress)
                    Text("تُستخدم فقط لأزرار «التوجّه إلى المنزل/العمل» واقتراح الوقت. لا تُرسل لأي خادم.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }

                Section(header: Text("الأدوات الذكية")) {
                    Text("• التوجّه إلى المنزل / العمل: يفتح خرائط Apple بالاتجاهات إلى العنوان الذي كتبته.\n• استئناف آخر صوت: يشغّل آخر رابط صوتي من موضعه المحفوظ.\n• فتح يوتيوب: يفتح تبويب يوتيوب داخل التطبيق على الهاتف.\n• اقتراح الوقت: قاعدة بسيطة حسب الساعة (صباحاً → العمل، مساءً → المنزل) — ليست ذكاءً اصطناعياً.")
                        .font(.subheadline)
                }

                Section(header: Text("اختصارات Siri")) {
                    Text("من تطبيق «الاختصارات» على الآيفون يمكنك إضافة أوامر صوتية: «التوجّه إلى المنزل»، «التوجّه إلى العمل»، «استئناف آخر صوت»، «افتح يوتيوب». كل أمر يفتح التطبيق وينفّذ الإجراء.")
                        .font(.subheadline)
                }

                Section(header: Text("عن التطبيق")) {
                    HStack {
                        Text("الاسم")
                        Spacer()
                        Text("كاربلاي برو")
                            .foregroundColor(.secondary)
                    }
                    HStack {
                        Text("الإصدار")
                        Spacer()
                        Text("1.0 (1)")
                            .foregroundColor(.secondary)
                    }
                    HStack {
                        Text("الحزمة")
                        Spacer()
                        Text("com.nebra.carplay")
                            .foregroundColor(.secondary)
                    }
                    Text("نسخة تجريبية تُثبَّت بشهادة. قوالب CarPlay كاملة في الكود لكن ظهورها على شاشة السيارة يتطلب صلاحية Apple لحساب مطوّر مدفوع.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .navigationTitle("الإعدادات")
        }
        .navigationViewStyle(.stack)
    }
}
