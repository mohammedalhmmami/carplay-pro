import SwiftUI
import WebKit

/// YouTube on the PHONE via WKWebView. Labelled phone-only everywhere:
/// YouTube video cannot appear on the car screen via CarPlay for
/// third-party apps — that is an Apple entitlement gate, not something
/// this app can bypass.
struct YouTubeView: View {
    @State private var searchText: String = ""
    @State private var currentURL: URL = YouTubeView.ytURL("https://www.youtube.com")
    @State private var showPhoneOnlyNote: Bool = true

    /// Builds a YouTube URL without force-unwrapping: the fallback is a
    /// file URL, which is guaranteed to construct.
    static func ytURL(_ string: String) -> URL {
        if let url = URL(string: string) { return url }
        return URL(fileURLWithPath: "/")
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                if showPhoneOnlyNote {
                    HStack {
                        Image(systemName: "iphone")
                        Text("يوتيوب هنا على الهاتف فقط — لا يظهر على شاشة السيارة")
                            .font(.caption)
                        Spacer()
                        Button(action: { showPhoneOnlyNote = false }) {
                            Image(systemName: "xmark")
                                .font(.caption)
                        }
                    }
                    .padding(8)
                    .background(Color.blue.opacity(0.12))
                    .foregroundColor(.blue)
                }

                HStack {
                    TextField("ابحث في يوتيوب…", text: $searchText)
                        .textFieldStyle(.roundedBorder)
                        .submitLabel(.search)
                        .onSubmit { searchYouTube() }
                    Button("بحث") { searchYouTube() }
                        .buttonStyle(.borderedProminent)
                }
                .padding(.horizontal)
                .padding(.vertical, 8)

                YouTubeWebView(url: $currentURL)
                    .edgesIgnoringSafeArea(.bottom)

                HStack(spacing: 20) {
                    Button("الرئيسية") {
                        currentURL = YouTubeView.ytURL("https://www.youtube.com")
                    }
                    Button("الموسيقى") {
                        currentURL = YouTubeView.ytURL("https://music.youtube.com")
                    }
                    Button("الاشتراكات") {
                        currentURL = YouTubeView.ytURL("https://www.youtube.com/feed/subscriptions")
                    }
                }
                .font(.subheadline)
                .padding(.vertical, 8)
            }
            .navigationTitle("يوتيوب")
            .navigationBarTitleDisplayMode(.inline)
        }
        .navigationViewStyle(.stack)
    }

    private func searchYouTube() {
        let query = searchText.trimmingCharacters(in: .whitespaces)
        guard !query.isEmpty,
              let encoded = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "https://www.youtube.com/results?search_query=\(encoded)") else { return }
        currentURL = url
    }
}

/// WKWebView wrapper. The web view is created ONCE in init (not in
/// updateUIView) so it is never recreated on state changes.
struct YouTubeWebView: UIViewRepresentable {
    @Binding var url: URL

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        if webView.url != url {
            webView.load(URLRequest(url: url))
        }
    }

    final class Coordinator: NSObject, WKNavigationDelegate {
        // Keep the delegate alive; no custom handling needed.
    }
}
